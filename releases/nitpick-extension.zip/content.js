(function(){"use strict";window.__nitpickInjected||(window.__nitpickInjected=!0,p());function p(){let i=null,n=null;chrome.runtime.onMessage.addListener((e,r,t)=>(e.type==="injectOverlay"?(u(),t({success:!0})):e.type==="removePin"&&(l(),t({success:!0})),!1));function u(){n||(l(),n=document.createElement("div"),n.id="__nitpick-capture-overlay",n.style.cssText=`
      position: fixed;
      inset: 0;
      background: transparent;
      cursor: crosshair;
      z-index: 2147483647;
    `,n.addEventListener("click",m),document.addEventListener("keydown",a,!0),document.documentElement.appendChild(n))}function a(e){e.key==="Escape"&&n&&(e.stopPropagation(),c(),chrome.runtime.sendMessage({type:"cancelPin"}))}function c(){n&&(n.remove(),n=null),document.removeEventListener("keydown",a,!0)}function m(e){e.preventDefault(),e.stopPropagation();const{clientX:r,clientY:t}=e,o=window.devicePixelRatio;i=f(r,t),document.documentElement.appendChild(i),c(),chrome.runtime.sendMessage({type:"pinPlaced",x:r,y:t,dpr:o,pageUrl:window.location.href})}function l(){i&&(i.remove(),i=null),c();const e=document.getElementById("__nitpick-pin-marker");e&&e.remove()}function f(e,r){const t=document.createElement("div");t.id="__nitpick-pin-marker",t.style.cssText=`
      position: fixed;
      left: ${e-18}px;
      top: ${r-38}px;
      width: 36px;
      height: 36px;
      z-index: 2147483646;
      pointer-events: none;
      display: flex;
      align-items: center;
      justify-content: center;
    `;const o=document.createElement("span");o.style.cssText=`
      position: absolute;
      inset: 0;
      border-radius: 50%;
      background: rgba(229,62,62,.18);
    `;const s=document.createElement("div");s.style.cssText=`
      width: 28px;
      height: 28px;
      background: rgb(229,62,62);
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      box-shadow: 0 0 0 2px #fff, 0 2px 6px rgba(0,0,0,.35);
      display: flex;
      align-items: center;
      justify-content: center;
    `;const d=document.createElement("span");return d.textContent="1",d.style.cssText=`
      transform: rotate(45deg);
      color: #fff;
      font: 700 12px Inter, sans-serif;
    `,s.appendChild(d),t.appendChild(o),t.appendChild(s),t}}})();
