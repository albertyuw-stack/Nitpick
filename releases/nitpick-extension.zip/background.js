const $ = "nitpick-secure", u = "keys", g = "aes-gcm";
function T() {
  return new Promise((r, t) => {
    const e = indexedDB.open($, 1);
    e.onupgradeneeded = () => e.result.createObjectStore(u), e.onsuccess = () => r(e.result), e.onerror = () => t(e.error);
  });
}
function U(r, t) {
  return new Promise((e, n) => {
    const a = r.transaction(u, "readonly").objectStore(u).get(t);
    a.onsuccess = () => e(a.result), a.onerror = () => n(a.error);
  });
}
function P(r, t, e) {
  return new Promise((n, a) => {
    const s = r.transaction(u, "readwrite");
    s.objectStore(u).put(e, t), s.oncomplete = () => n(), s.onerror = () => a(s.error);
  });
}
let f = null;
async function k() {
  if (f) return f;
  const r = await T();
  let t = await U(r, g);
  return t || (t = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    !1,
    // non-extractable: the raw key can never be read by script
    ["encrypt", "decrypt"]
  ), await P(r, g, t)), f = t, t;
}
function w(r) {
  return btoa(String.fromCharCode(...new Uint8Array(r)));
}
function b(r) {
  const t = atob(r), e = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++) e[n] = t.charCodeAt(n);
  return e;
}
async function S(r) {
  const t = await k(), e = crypto.getRandomValues(new Uint8Array(12)), n = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: e },
    t,
    new TextEncoder().encode(r)
  );
  return { iv: w(e.buffer), data: w(n) };
}
async function A(r) {
  const t = await k(), e = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: b(r.iv) },
    t,
    b(r.data)
  );
  return new TextDecoder().decode(e);
}
class I {
  constructor() {
    this.config = null;
  }
  async loadConfig() {
    if (this.config) return this.config;
    const e = (await chrome.storage.local.get(["jiraConfig"])).jiraConfig;
    if (!(e != null && e.baseUrl)) return null;
    if (e.token)
      return this.config = { baseUrl: e.baseUrl, token: e.token, deploymentType: e.deploymentType }, await this.saveConfig(this.config), this.config;
    if (!e.auth) return null;
    try {
      const n = await A(e.auth);
      return this.config = { baseUrl: e.baseUrl, token: n, deploymentType: e.deploymentType }, this.config;
    } catch {
      return await this.clearConfig(), null;
    }
  }
  async saveConfig(t) {
    this.config = t;
    const e = {
      baseUrl: t.baseUrl,
      deploymentType: t.deploymentType,
      auth: await S(t.token)
    };
    await chrome.storage.local.set({ jiraConfig: e });
  }
  async clearConfig() {
    this.config = null, await chrome.storage.local.remove("jiraConfig");
  }
  async connect(t, e, n) {
    const a = t.replace(/\/+$/, "");
    try {
      const o = new URL(a).origin;
      if (!await chrome.permissions.contains({ origins: [`${o}/*`] }))
        return { success: !1, error: "Host permission for the Jira domain was not granted" };
    } catch {
      return { success: !1, error: "Invalid Jira URL" };
    }
    const s = n ? `Basic ${btoa(`${n}:${e}`)}` : `Bearer ${e}`;
    try {
      const o = await fetch(`${a}/rest/api/2/serverInfo`, {
        headers: { Authorization: s }
      });
      if (!o.ok)
        return { success: !1, error: `Could not reach Jira (HTTP ${o.status})` };
      const p = (await o.json()).deploymentType === "Cloud" ? "Cloud" : "DataCenter", d = await fetch(`${a}/rest/api/2/myself`, {
        headers: { Authorization: s }
      });
      if (!d.ok)
        return { success: !1, error: d.status === 401 ? "Invalid credentials" : `Auth check failed (HTTP ${d.status})` };
      const m = await d.json();
      return await this.saveConfig({ baseUrl: a, token: s, deploymentType: p }), { success: !0, deploymentType: p, displayName: m.displayName || m.name };
    } catch (o) {
      return { success: !1, error: `Connection failed: ${o instanceof Error ? o.message : String(o)}` };
    }
  }
  async testConnection() {
    try {
      const t = await this.apiFetch("/rest/api/2/myself");
      return { success: !0, displayName: t.displayName || t.name };
    } catch (t) {
      return { success: !1, error: String(t) };
    }
  }
  async getTicket(t) {
    var e, n;
    try {
      const a = await this.requireConfig(), s = await this.apiFetch(`/rest/api/2/issue/${encodeURIComponent(t)}?fields=summary,status,assignee`);
      return {
        key: s.key,
        summary: s.fields.summary,
        status: ((e = s.fields.status) == null ? void 0 : e.name) || "Unknown",
        assignee: ((n = s.fields.assignee) == null ? void 0 : n.displayName) || null,
        url: `${a.baseUrl}/browse/${s.key}`
      };
    } catch {
      return null;
    }
  }
  async attachScreenshot(t, e, n) {
    try {
      const a = await this.requireConfig(), s = new FormData();
      s.append("file", e, n);
      const o = await fetch(`${a.baseUrl}/rest/api/2/issue/${encodeURIComponent(t)}/attachments`, {
        method: "POST",
        headers: {
          Authorization: a.token,
          "X-Atlassian-Token": "no-check"
        },
        body: s
      });
      return o.ok ? { success: !0 } : { success: !1, error: `HTTP ${o.status}` };
    } catch (a) {
      return { success: !1, error: String(a) };
    }
  }
  async postComment(t, e, n, a) {
    try {
      const s = await this.requireConfig(), o = this.buildWikiCommentBody(e, n, a), l = await fetch(`${s.baseUrl}/rest/api/2/issue/${encodeURIComponent(t)}/comment`, {
        method: "POST",
        headers: {
          Authorization: s.token,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(o)
      });
      return l.ok ? { success: !0 } : { success: !1, error: `HTTP ${l.status}` };
    } catch (s) {
      return { success: !1, error: String(s) };
    }
  }
  buildWikiCommentBody(t, e, n) {
    return {
      body: `${t}

!${e}|width=600!
Pin location: ${n}`
    };
  }
  async apiFetch(t) {
    const e = await this.requireConfig(), n = await fetch(`${e.baseUrl}${t}`, {
      headers: { Authorization: e.token }
    });
    if (!n.ok)
      throw new Error(`Jira API error: HTTP ${n.status}`);
    return n.json();
  }
  async requireConfig() {
    const t = await this.loadConfig();
    if (!t)
      throw new Error("Jira not configured");
    return t;
  }
}
const v = /[A-Z][A-Z0-9]{1,9}-\d+/;
function j(r) {
  const t = (r ?? "").trim().replace(/-+$/, "");
  if (!t) return null;
  const e = t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`${e}-\\d+`, "i");
}
async function E() {
  try {
    const { ticketProject: r } = await chrome.storage.local.get(["ticketProject"]), t = j(r ?? "");
    if (t) return t;
  } catch {
  }
  return v;
}
const c = new I();
let i = null;
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch(() => {
});
chrome.runtime.onMessage.addListener((r, t, e) => {
  var n;
  return R(r, (n = t.tab) == null ? void 0 : n.id).then(e).catch((a) => e({ success: !1, error: String(a) })), !0;
});
chrome.tabs.onActivated.addListener(async ({ tabId: r }) => {
  try {
    const t = await chrome.tabs.get(r);
    C(t.url);
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((r, t, e) => {
  t.status === "complete" && C(e.url);
});
async function C(r) {
  if (!r) return;
  const t = await E(), e = r.match(t);
  e && y({ type: "urlTicketDetected", key: e[0] });
}
async function R(r, t) {
  switch (r.type) {
    case "connect":
      return c.connect(r.baseUrl, r.token, r.email);
    case "disconnect":
      return await c.clearConfig(), { success: !0 };
    case "testConnection":
      return c.testConnection();
    case "validateTicket": {
      const e = await c.getTicket(r.key);
      return e ? { success: !0, ticket: e } : { success: !1, error: "Ticket not found" };
    }
    case "startPinMode": {
      i = r.tabId;
      try {
        await chrome.scripting.executeScript({
          target: { tabId: r.tabId },
          files: ["content.js"]
        });
      } catch {
        return { success: !1, error: "Pins can't be placed on this page" };
      }
      return await chrome.tabs.sendMessage(r.tabId, { type: "injectOverlay" }), { success: !0 };
    }
    case "pinPlaced": {
      const e = t ?? i;
      if (e === null)
        return { success: !1, error: "No active pin tab" };
      await new Promise((n) => setTimeout(n, 60));
      try {
        const n = await chrome.tabs.get(e), a = await chrome.tabs.captureVisibleTab(n.windowId, { format: "png" });
        return y({
          type: "screenshotReady",
          dataUrl: a,
          pin: { x: r.x, y: r.y, dpr: r.dpr, pageUrl: r.pageUrl }
        }), { success: !0 };
      } catch (n) {
        h();
        const a = n instanceof Error ? n.message : String(n);
        return y({ type: "pinError", message: `Failed to capture screenshot: ${a}` }), { success: !1, error: a };
      }
    }
    case "submit": {
      const e = await D(r.imageDataUrl), n = M(r.key), a = await c.attachScreenshot(r.key, e, n);
      if (!a.success)
        return { success: !1, error: `Attachment failed: ${a.error}`, stage: "attachment" };
      const s = `(${Math.round(r.pin.x)}, ${Math.round(r.pin.y)}) at ${r.pin.pageUrl}`, o = await c.postComment(r.key, r.comment, n, s);
      return o.success ? (h(), { success: !0 }) : {
        success: !1,
        error: `Screenshot attached, but comment failed: ${o.error}`,
        stage: "comment",
        filename: n
      };
    }
    case "cancelPin":
      return h(), { success: !0 };
    default:
      return { success: !1, error: "Unknown message type" };
  }
}
function h() {
  i !== null && (chrome.tabs.sendMessage(i, { type: "removePin" }).catch(() => {
  }), i = null);
}
function M(r) {
  const t = /* @__PURE__ */ new Date(), e = (a) => String(a).padStart(2, "0"), n = `${t.getFullYear()}${e(t.getMonth() + 1)}${e(t.getDate())}-${e(t.getHours())}${e(t.getMinutes())}`;
  return `pin-${r}-${n}.png`;
}
function y(r) {
  chrome.runtime.sendMessage(r).catch(() => {
  });
}
async function D(r) {
  return (await fetch(r)).blob();
}
